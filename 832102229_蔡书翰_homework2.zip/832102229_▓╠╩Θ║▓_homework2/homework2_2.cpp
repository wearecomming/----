#include<iostream>
int main(){
    double d=8,i=21.4,s=20000,c=3;
    double l=s*i/d/c;
    std::cout<<"The maximum load that can be placed is:"<<l<<std::endl;
    return 0;
}