#include<iostream>
using namespace std;
int main(){
    cout<<"please input a number:";
    int x;
    cin>>x;
    if(x%2)cout<<"This number is Odd";
    else cout<<"This number is Even";
    return 0;
}