#include<iostream>
#include<cstdio>
#include "homework11_1a.cpp"
using namespace std;
int main(){
    Savings s;
    s.cal(65,0.1);
    s.display();
    return 0;
}
