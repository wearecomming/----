#include<iostream>
#include<cstdio>
#include "homework12_2a.cpp"
using namespace std;
int main(){
    Cartesian a;
    Cartesian b;
    cout<<a<<b;
    cin>>a>>b;
    cout<<a<<b;
    b=a;
    cout<<a<<b;
    return 0;
}